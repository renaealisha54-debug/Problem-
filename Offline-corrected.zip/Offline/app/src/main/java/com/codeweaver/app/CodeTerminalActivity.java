package com.codeweaver.app;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class CodeTerminalActivity extends AppCompatActivity {

    private EditText terminalInput;
    private CodeAnalyzerService analyzer;
    private ProjectDatabaseHelper dbHelper;
    private FileExporter exporter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_terminal);

        terminalInput = findViewById(R.id.terminal_input);
        analyzer = new CodeAnalyzerService();
        dbHelper = new ProjectDatabaseHelper(this);
        exporter = new FileExporter();

        terminalInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                onCodeChanged(s.toString());
            }
        });
    }

    private void onCodeChanged(String text) {
        if (analyzer.isSyntaxValid(text)) {
            terminalInput.setBackgroundColor(0xFF313244);
        } else {
            terminalInput.setBackgroundColor(0x33F38BA8);
        }
    }

    private void handleSave(String title, String notes) {
        String currentCode = terminalInput.getText().toString();
        dbHelper.saveProject(title, "Java", notes, currentCode);
    }
}
