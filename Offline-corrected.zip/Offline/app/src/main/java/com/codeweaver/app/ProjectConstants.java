package com.codeweaver.app;

public class ProjectConstants {
    public static final String APP_NAME   = "Off - Offline Code Editor";
    public static final String VERSION    = "1.0.0";
    public static final String PACKAGE    = "com.codeweaver.app";
    public static final String DB_NAME    = "codeweaver.db";
    public static final int    DB_VERSION = 1;
}
