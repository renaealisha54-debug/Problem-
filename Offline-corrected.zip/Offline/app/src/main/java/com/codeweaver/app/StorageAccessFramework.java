package com.codeweaver.app;

import android.app.Activity;
import android.content.Intent;

public class StorageAccessFramework {

    public static final int REQUEST_OPEN_DOCUMENT   = 1001;
    public static final int REQUEST_CREATE_DOCUMENT = 1002;

    public static void openFile(Activity activity) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        activity.startActivityForResult(intent, REQUEST_OPEN_DOCUMENT);
    }

    public static void createFile(Activity activity, String suggestedName) {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, suggestedName);
        activity.startActivityForResult(intent, REQUEST_CREATE_DOCUMENT);
    }
}
