package com.codeweaver.app;

import android.content.Intent;

public class FileExporter {

    public String getExtension(String language) {
        switch (language) {
            case "Kotlin":     return ".kt";
            case "Python":     return ".py";
            case "JavaScript": return ".js";
            case "Gradle":     return ".gradle";
            case "Java":       return ".java";
            default:           return ".txt";
        }
    }

    public Intent getExportIntent(String fileName, String language) {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, fileName + getExtension(language));
        return intent;
    }
}
