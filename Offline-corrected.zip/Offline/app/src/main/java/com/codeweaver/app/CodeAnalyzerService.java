package com.codeweaver.app;

import java.util.Stack;

public class CodeAnalyzerService {

    public boolean isSyntaxValid(String code) {
        Stack<Character> stack = new Stack<>();
        for (char c : code.toCharArray()) {
            if (c == '{' || c == '(' || c == '[') {
                stack.push(c);
            } else if (c == '}' || c == ')' || c == ']') {
                if (stack.isEmpty()) return false;
                char last = stack.pop();
                if ((c == '}' && last != '{') ||
                    (c == ')' && last != '(') ||
                    (c == ']' && last != '[')) {
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }

    public String autoFormat(String code) {
        StringBuilder formatted = new StringBuilder();
        int indentLevel = 0;
        for (String line : code.split("\n")) {
            line = line.trim();
            if (line.startsWith("}") || line.startsWith("]")) indentLevel--;
            if (indentLevel < 0) indentLevel = 0;
            for (int i = 0; i < indentLevel; i++) formatted.append("    ");
            formatted.append(line).append("\n");
            if (line.endsWith("{") || line.endsWith("[")) indentLevel++;
        }
        return formatted.toString().trim();
    }
}
