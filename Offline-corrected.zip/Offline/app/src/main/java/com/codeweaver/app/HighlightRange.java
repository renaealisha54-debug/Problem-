package com.codeweaver.app;

public class HighlightRange {

    public final int start;
    public final int end;
    public final int color;

    public HighlightRange(int start, int end, int color) {
        this.start = start;
        this.end   = end;
        this.color = color;
    }
}
