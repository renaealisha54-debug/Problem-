package com.codeweaver.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ProjectDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME     = "codeweaver.db";
    private static final int    DB_VERSION  = 1;

    private static final String TABLE      = "projects";
    private static final String COL_ID      = "id";
    private static final String COL_TITLE   = "title";
    private static final String COL_LANG    = "language";
    private static final String COL_NOTES   = "notes";
    private static final String COL_CODE    = "code";
    private static final String COL_CREATED = "created_at";

    public ProjectDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
            "CREATE TABLE " + TABLE + " (" +
            COL_ID      + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_TITLE   + " TEXT NOT NULL, " +
            COL_LANG    + " TEXT, " +
            COL_NOTES   + " TEXT, " +
            COL_CODE    + " TEXT, " +
            COL_CREATED + " TEXT" +
            ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public long saveProject(String title, String language, String notes, String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE,   title);
        values.put(COL_LANG,    language);
        values.put(COL_NOTES,   notes);
        values.put(COL_CODE,    code);
        values.put(COL_CREATED, Timestamp.getCurrentTimestamp());
        return db.insertOrThrow(TABLE, null, values);
    }

    public void saveNotes(int projectId, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NOTES, notes);
        db.update(TABLE, values, COL_ID + " = ?",
            new String[]{ String.valueOf(projectId) });
    }

    public String getNotes() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT " + COL_NOTES + " FROM " + TABLE +
            " ORDER BY " + COL_ID + " DESC LIMIT 1", null);
        if (cursor.moveToFirst()) {
            String notes = cursor.getString(0);
            cursor.close();
            return notes != null ? notes : "";
        }
        cursor.close();
        return "";
    }
}
