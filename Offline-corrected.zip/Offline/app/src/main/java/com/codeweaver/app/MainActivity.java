package com.codeweaver.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText terminalInput;
    private ProjectDatabaseHelper dbHelper;
    private CodeAnalyzerService analyzer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        terminalInput = findViewById(R.id.multiLineEditText);
        dbHelper      = new ProjectDatabaseHelper(this);
        analyzer      = new CodeAnalyzerService();

        Button btnScan   = findViewById(R.id.btn_scan);
        Button btnSave   = findViewById(R.id.btn_save);
        Button btnExport = findViewById(R.id.btn_export);

        btnScan.setOnClickListener(v -> {
            String code = terminalInput.getText().toString();
            if (analyzer.isSyntaxValid(code)) {
                terminalInput.setText(analyzer.autoFormat(code));
                terminalInput.setBackgroundColor(0xFF313244);
            } else {
                terminalInput.setBackgroundColor(0x33F38BA8);
            }
        });

        btnSave.setOnClickListener(v -> {
            String code = terminalInput.getText().toString();
            dbHelper.saveProject("Project_" + Timestamp.getCurrentTimestamp(), "Java", "", code);
        });

        btnExport.setOnClickListener(v -> {
            FileExporter exporter = new FileExporter();
            Intent intent = exporter.getExportIntent("export_" + Timestamp.getFileTimestamp(), "Java");
            startActivityForResult(intent, 101);
        });
    }
}
