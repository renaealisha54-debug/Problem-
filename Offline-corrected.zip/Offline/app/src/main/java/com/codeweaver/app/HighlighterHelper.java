package com.codeweaver.app;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import java.util.List;

public class HighlighterHelper {

    public static SpannableString applyHighlights(String text, List<HighlightRange> ranges) {
        SpannableString spannable = new SpannableString(text);
        for (HighlightRange range : ranges) {
            if (range.start >= 0 && range.end <= text.length() && range.start < range.end) {
                spannable.setSpan(
                    new BackgroundColorSpan(range.color),
                    range.start,
                    range.end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                );
            }
        }
        return spannable;
    }
}
