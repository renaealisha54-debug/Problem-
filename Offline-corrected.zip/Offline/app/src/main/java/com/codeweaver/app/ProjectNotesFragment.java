package com.codeweaver.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProjectNotesFragment extends Fragment {

    private EditText notesInput;
    private ProjectDatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_notes, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        notesInput = view.findViewById(R.id.notesInput);
        dbHelper   = new ProjectDatabaseHelper(requireContext());
        notesInput.setText(dbHelper.getNotes());

        notesInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                dbHelper.saveNotes(0, notesInput.getText().toString());
            }
        });
    }
}
