# Offline — Code Editor for Android

An offline-first Android code editor built in Java. Write, validate, format, save, and export code entirely on-device with no internet connection required.

---

## Features

- Live syntax validation using bracket and parenthesis matching with error highlight
- Auto-formatter that applies 4-space indentation across nested blocks
- SQLite database storage for projects — title, language, notes, code, and timestamp
- File export using Android Storage Access Framework with correct extension per language
- Project notes fragment for freeform per-session notes saved to the database
- ZIP entry placement analyzer that sorts file types into logical destination folders
- Runtime permission handling for storage access across Android API 26 through 34

---

## Project Structure

```
app/src/main/AndroidManifest.xml
app/src/main/java/com/codeweaver/app/MainActivity.java
app/src/main/java/com/codeweaver/app/CodeTerminalActivity.java
app/src/main/java/com/codeweaver/app/CodeAnalyzerService.java
app/src/main/java/com/codeweaver/app/ProjectDatabaseHelper.java
app/src/main/java/com/codeweaver/app/ProjectNotesFragment.java
app/src/main/java/com/codeweaver/app/ProjectConstants.java
app/src/main/java/com/codeweaver/app/HighlighterHelper.java
app/src/main/java/com/codeweaver/app/HighlightRange.java
app/src/main/java/com/codeweaver/app/FileExporter.java
app/src/main/java/com/codeweaver/app/StorageAccessFramework.java
app/src/main/java/com/codeweaver/app/Timestamp.java
app/src/main/java/com/codeweaver/app/ZipDeconstructor.java
app/src/main/java/com/codeweaver/app/PermissionManager.java
app/src/main/res/layout/activity_main.xml
app/src/main/res/layout/activity_code_terminal.xml
app/src/main/res/layout/fragment_notes.xml
app/build.gradle
build.gradle
settings.gradle
```

---

## Requirements

- Android 8.0 or higher (minSdk 26)
- targetSdk 34
- Java 11
- Android Studio Hedgehog or newer

---

## Build Instructions

1. Clone or download the repository
2. Open in Android Studio
3. Let Gradle sync complete
4. Run on a device or emulator running Android 8.0+

---

## Supported Export Languages

| Language   | Extension |
|------------|-----------|
| Java       | .java     |
| Kotlin     | .kt       |
| Python     | .py       |
| JavaScript | .js       |
| Gradle     | .gradle   |
| Plain text | .txt      |

---

## Permissions

| Permission | Applies To |
|---|---|
| READ_EXTERNAL_STORAGE | API 32 and below |
| WRITE_EXTERNAL_STORAGE | API 29 and below |
| READ_MEDIA_DOCUMENTS | File picker access |
| RECEIVE_BOOT_COMPLETED | Future background task support |

On Android 13+ scoped storage applies and no permission prompt is shown.

---

## License

MIT License — Copyright 2026 Alisha (renaealisha54-debug)
